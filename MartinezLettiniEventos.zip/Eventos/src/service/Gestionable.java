
package service;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public interface Gestionable<T> {
    
    
    void agregarEvento (T evento);
    
    void eliminar(int indice);
    
    T obtener(int indice);
    
    void limpiarElementos();
    
    
    void ordenPorCriterioNatural();
    void ordenPorCriterioPersonalizado(Comparator<T> comparator);

    
    List<T> filtrarElementos(Predicate<T> criterio);
    
    
    void guardarElementosBinarios(String archivo) throws IOException, ClassNotFoundException;
    
    
    void cargarElementosBinarios(String archivo)throws IOException, ClassNotFoundException;
    
    
    void guardarElementosCSV(String archivo)throws IOException;
    
    
    
    void cargarElementosCSV(String archivo , Function<String, T> transformadora) throws IOException;

    
    void mostrarTodos();
}
