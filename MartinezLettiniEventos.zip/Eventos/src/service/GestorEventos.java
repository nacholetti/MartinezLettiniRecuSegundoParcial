
package service;

import data.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class GestorEventos<T extends CSVSerializable & Comparable<T>> implements Gestionable<T> {
    private List<T> eventos;

    public GestorEventos(List<T> eventos) {
        this.eventos = eventos;
    }

    @Override
    public void agregarEvento(T evento) {
        if(evento == null){
           throw new IllegalArgumentException("No puedo almacenar algo nulo");
       }
        
        eventos.add(evento);
    }

    @Override
    public void eliminar(int indice) {
        if (indice >= 0 && indice < eventos.size()) {
            eventos.remove(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }

    @Override
    public T obtener(int indice) {
         if(indice>=0 && indice < eventos.size()){
           return eventos.get(indice);
       }
       throw new IndexOutOfBoundsException("Fuera de rango");
    }

    @Override
    public void limpiarElementos() {
        eventos.clear();
    }

    @Override
    public void ordenPorCriterioNatural() {
      Collections.sort(eventos);
    }

    @Override
    public void ordenPorCriterioPersonalizado(Comparator<T> comparator) {
        eventos.sort(comparator);
    }

    @Override
    public List<T> filtrarElementos(Predicate<T> criterio) {
        
       List<T> toReturn = new ArrayList<>();
       for(T evento: eventos){
           if(criterio.test(evento)){
               toReturn.add(evento);
           }
       }
        return toReturn;
    }

    @Override
    public void guardarElementosBinarios(String archivo) throws IOException{
          ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo));
           salida.writeObject(eventos);
           salida.close();
    }

    @Override
    public void cargarElementosBinarios(String archivo) throws IOException, ClassNotFoundException {
        eventos.clear();
        
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(archivo));
        
        eventos.addAll((List<T>) entrada.readObject());
        
        entrada.close();
        
    }

    @Override
    public void guardarElementosCSV(String archivo)throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
        bw.write(eventos.get(0).toHeaderCSV());
        for(T evento : eventos){
            bw.write(evento.toCSV() + "\n");
        }
        bw.close();
    }

    @Override
    public void cargarElementosCSV(String archivo, Function<String, T> transformadora) throws IOException {
        eventos.clear();
        BufferedReader br = new BufferedReader(new FileReader(archivo));
        
        String linea = "";
        br.readLine();
        
        while((linea = br.readLine()) != null){
            eventos.add(transformadora.apply(linea));
        }
        br.close();
    }

    @Override
    public void mostrarTodos() {
        for (T evento: eventos) {
            System.out.println(evento);}
    }

    
    
    
}
