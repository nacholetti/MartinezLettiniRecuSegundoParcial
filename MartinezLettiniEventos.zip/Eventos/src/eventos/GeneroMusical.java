
package eventos;


public enum GeneroMusical {
    ROCK,
    JAZZ,
    POP,
    CLASICA,
    ELECTRONICA
}
