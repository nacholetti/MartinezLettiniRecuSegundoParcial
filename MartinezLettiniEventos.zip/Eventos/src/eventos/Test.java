
package eventos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import service.GestorEventos;


public class Test {

   
    public static void main(String[] args) {
    List<EventoMusical> listaDeEventos = new ArrayList<>();
        
   GestorEventos<EventoMusical> gestor = new GestorEventos<>(listaDeEventos);
 // Agregar eventos musicales
 gestor.agregarEvento(new EventoMusical("Elvis Presley", GeneroMusical.ROCK, 10, "Lola", LocalDate.EPOCH));
 gestor.agregarEvento(new EventoMusical("Ringo Star", GeneroMusical.ROCK, 12, "Cosquin", LocalDate.EPOCH));
 


 // Mostrar eventos agregados
 System.out.println("Eventos iniciales:");
 gestor.mostrarTodos();
 // Filtrar eventos por género

 System.out.println("\nFiltrar por género: ROCK");
 List<EventoMusical> rockEventos = gestor.filtrarElementos((evento -> evento.getGenero()) == GeneroMusical.ROCK)
         .forEach(evento -> System.out.println(evento));
         /* Acá va una expresión
lambda*/
 rockEventos.forEach(System.out::println);
 // Filtrar eventos por rango de fechas
 System.out.println("\nFiltrar por rango de fechas (2024-12-01 a 2024-12-
31):");
 List<EventoMusical> rangoFechas = gestor.filtrar(/* Acá va una expresión
lambda*/);
 rangoFechas.forEach(System.out::println);
 // Ordenar eventos por nombre
 System.out.println("\nEventos ordenados por nombre:");
 gestor.ordenar(/* Acá va una expresión lambda*/);
 gestor.mostrarTodos();
 // Ordenar eventos por fecha
 System.out.println("\nEventos ordenados por fecha:");
 gestor.ordenar((/* Acá va una expresión lambda*/);
 gestor.mostrarTodos();
 // Guardar y cargar en archivo binario
 gestor.guardarEnBinario(AppConfig.PATH_SER.toString());
 GestorEventos<EventoMusical> gestorBinario = new GestorEventos<>();
 gestorBinario.cargarDesdeBinario(AppConfig.PATH_SER.toString());
 System.out.println("\nEventos cargados desde archivo binario:");
 gestorBinario.mostrarTodos();
 // Guardar y cargar en archivo CSV
 gestor.guardarEnCSV(AppConfig.PATH_CSV.toString());
 GestorEventos<EventoMusical> gestorCSV = new GestorEventos<>();
 gestorCSV.cargarDesdeCSV(AppConfig.PATH_CSV.toString(),/* Acá va una
expresión lambda*/);
 System.out.println("\nEventos cargados desde archivo CSV:");
 gestorCSV.mostrarTodos();
 // Eliminar evento
 System.out.println("\nEliminar evento con índice 1:");
 gestor.eliminar(1);
 gestor.mostrarTodos();
    }
    
}
