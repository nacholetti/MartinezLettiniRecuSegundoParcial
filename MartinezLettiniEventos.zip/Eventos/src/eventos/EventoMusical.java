
package eventos;

import data.CSVSerializable;
import java.time.LocalDate;

/*String artista: nombre del artista principal del evento.
▪ GeneroMusical genero: un enumerado con los valores ROCK, JAZZ, POP, CLASICA,
ELECTRONICA*/
public class EventoMusical extends Evento implements CSVSerializable, Comparable<EventoMusical> {
    
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(String artista, GeneroMusical genero, int id, String nombre, LocalDate fecha) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }
    
                /*compareTo para ordenar eventos por fecha.
            ▪ Métodos para transformar un evento a formato CSV (toCSV) y generar un
            encabezado (toHeaderCSV).
            ▪ Un método estático fromCSV para convertir una línea de texto CSV en un objeto
            EventoMusical.
            */
    
    
    
    
    public int compareTo(Evento otroEvento){
        
        if (this.equals(otroEvento)) {
            System.out.println("El evento es igual");
    } 
        /*Si no son iguales*/
        return this.getFecha().compareTo(otroEvento.getFecha());
    
        
    }

    public GeneroMusical getGenero() {
        return genero;
    }
    
    
    
    
    
    
    @Override
    public String toCSV() {
        return this.getId() + "," + this.getNombre() + "," + this.getFecha() + "," + this.artista + "," + this.genero;
    }

    
    @Override
    public  String toHeaderCSV() {
        return "ID,Nombre,Fecha,Artista,Genero";
    }
    public static EventoMusical fromCSV(String csvLine) {
        
        String[] values = csvLine.split(",");
        
       
        if (values.length != 5) {
            throw new IllegalArgumentException("Línea CSV no válida, se esperaban 5 valores.");
        }

      
        int id = Integer.parseInt(values[0]);  
        String nombre = values[1];           
        LocalDate fecha = LocalDate.parse(values[2]); 
        String artista = values[3];            
        GeneroMusical genero = GeneroMusical.valueOf(values[4].toUpperCase()); 

        
        return new EventoMusical(artista, genero, id, nombre, fecha);
    }

    @Override
    public int compareTo(EventoMusical o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
