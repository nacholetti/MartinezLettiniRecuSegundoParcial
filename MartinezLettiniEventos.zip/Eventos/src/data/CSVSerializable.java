
package data;


public interface CSVSerializable {
    String toCSV();
    
    String toHeaderCSV();
}
